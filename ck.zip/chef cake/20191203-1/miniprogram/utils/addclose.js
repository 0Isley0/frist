class Addclose {

}
var list1 = ''
var list = ''

var out_trade_no = ''
//结算
function setclose(res) {
  list1 = res.trade_state_desc
  console.log(list1,'ll')
}

function getclevn() {
  return list1
}

function closid() {

  return out_trade_no
}

function setsid(out_trade_no1) {

  out_trade_no = out_trade_no1
}

function removebot() {
  const db = wx.cloud.database()

  db.collection('remove').doc(list2.out_trade_no).remove({
    success: function(res) {
      console.log(res, '999')

    }
  })

}

function removess(bblist) {


  var sslist = wx.getStorageSync('cart')
  var ddlist = bblist
  var vvlist = []
  for (let i in sslist) {
    for (let j in ddlist) {

      if (sslist[i].id == ddlist[j].id) {

        sslist.splice(i, 1);

      }

    }
  }


  wx.setStorageSync('cart', sslist);


}

module.exports = {
  setclose: setclose,
  getclevn: getclevn,
  closid: closid,
  setsid: setsid,
  removebot: removebot,
  removess: removess,
}