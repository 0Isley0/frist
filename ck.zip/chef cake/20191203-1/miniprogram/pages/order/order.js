import {
  Order
} from '../order/order-model.js';
import {
  Cart
} from '../cart/cart-model.js';
import {
  Address
} from '../../utils/address.js';

var order = new Order();
var cart = new Cart();
var address = new Address();
var pay = require('../../utils/pay.js')
var timestamp = Date.parse(new Date());
var addclose = require('../../utils/addclose.js')

Page({
  data: {
    fromCartFlag: true,
    addressInfo: null,
    timer: '', //定时器名字
    countDownNum: '60' //倒计时初始值

  },

  /*
   * 订单数据来源包括两个：
   * 1.购物车下单
   * 2.旧的订单
   * */
  onLoad: function(options) {
    var flag = options.from == 'cart',
      that = this;
    this.data.fromCartFlag = flag;
    this.data.account = options.account;


    //来自于购物车
    if (flag) {
      this.setData({
        productsArr: cart.getCartDataFromLocal(true),
        account: options.account,
        orderStatus: 0
      });

      /*显示收获地址*/
      address.getAddress((res) => {
        that._bindAddressInfo(res);
      });
    }

    //旧订单
    else {
      this.data.id = options.id;
    }
  },

  countDown: function() {
    let that = this;
    let countDownNum = that.data.countDownNum; //获取倒计时初始值
    //如果将定时器设置在外面，那么用户就看不到countDownNum的数值动态变化，所以要把定时器存进data里面
    that.setData({
      timer: setInterval(function() { //这里把setInterval赋值给变量名为timer的变量
        //每隔一秒countDownNum就减一，实现同步
        countDownNum--;
        //然后把countDownNum存进data，好让用户知道时间在倒计着
        pay.payCheck()
        
        if (addclose.getclevn() == "支付成功") {

          that.printer();
          console.log('333')
          clearInterval(that.data.timer);
        }
    
        that.setData({
          countDownNum: countDownNum
        })

        


        console.log(countDownNum)
        //在倒计时还未到0时，这中间可以做其他的事情，按项目需求来
        if (countDownNum == 0) {
          

          //这里特别要注意，计时器是始终一直在走的，如果你的时间为0，那么就要关掉定时器！不然相当耗性能
          //因为timer是存在data里面的，所以在关掉时，也要在data里取出后再关闭
          clearInterval(that.data.timer);
          //关闭定时器之后，可作其他处理codes go here
          
         
        }

      }, 1000)
    })
  },





  getTradeNo(e) {
    var t = this,
      trade_no = e.detail.value.trim(),
      refund_no = 'refund' + trade_no
    t.setData({
      trade_no: trade_no,
      refund_no: refund_no
    })
  },
  pay() {
    // 支付订单
    var t = this

    t.setData({
      type: 'unify'
    })
    this.wxPayment()
    
  },

  onShow: function() {
    if (this.data.id) {
      var that = this;
      //下单后，支付成功或者失败后，点左上角返回时能够更新订单状态 所以放在onshow中
      var id = this.data.id;
      order.getOrderInfoById(id, (data) => {
        that.setData({
          orderStatus: data.status,
          productsArr: data.snap_items,
          account: data.total_price,
          basicInfo: {
            orderTime: data.create_time,
            orderNo: data.order_no
          },
        });

        // 快照地址
        var addressInfo = data.snap_address;
        addressInfo.totalDetail = address.setAddressInfo(addressInfo);
        that._bindAddressInfo(addressInfo);
      });
    }
  },

  printer: function() {
    var that = this
    const db = wx.cloud.database()
    db.collection('order').where({}).get({
      success: function(res) {
        for (let i = 0; i < res.data.length; i++) {
          var dd = res.data[i]
        }

        order.getOrderd(dd, (data) => {
         
          wx.cloud.callFunction({
            name: 'add_deliveryStatus',
            data: {
              tpOrderId1: dd.tpOrderId,
              orderId1: data.result.orderId,
            },
            success: function(res) {         
              
              that.getList1()

            },

          })


        })
       
      }
    })
  },


  getList1: function() {
    const db = wx.cloud.database()
    db.collection('order').field({
      orderId2: true,
      tpOrderId: true,
      
    }).get({
      success: function(res) {

        for (var i = 0; i < res.data.length; i++) {

          var dd1 = res.data[i]    
        }
        order.getOrderdd(dd1, (data1) => {
          console.log(dd1, 'kkkk')
          wx.cloud.callFunction({
            name: 'add_deliveryStatus1',
            data: {
              orderId1: data1.orderId,
              deliveryStatus: data1.deliveryStatus,
            },
            success: function(res) {
              

            },

          })
        })
     
      }
    })

  },

  /*修改或者添加地址信息*/
  editAddress: function() {
    var that = this;
    wx.chooseAddress({
      success: function(res) {
        var addressInfo = {
          name: res.userName,
          mobile: res.telNumber,
          totalDetail: address.setAddressInfo(res)
        };
        that._bindAddressInfo(addressInfo);

        //保存地址
        address.submitAddress(res, (flag) => {
          if (!flag) {
            that.showTips('操作提示', '地址信息更新失败！');
          }
        });
      }
    })
  },

  /*绑定地址信息*/
  _bindAddressInfo: function(addressInfo) {
    this.setData({
      addressInfo: addressInfo
    });
  },

  /*下单和付款*/
  pay: function() {
   
    if (!this.data.addressInfo) {
      this.showTips('下单提示', '请填写您的收货地址');
      return;
    }
    if (this.data.orderStatus == 0) {
      var bblist = this.data.productsArr
      addclose.removess(bblist)
      this._firstTimePay();



    } else {
      this._oneMoresTimePay();
    }
  },

  /*第一次支付*/
  _firstTimePay: function() {
    var that = this;
    this.countDown();



    var addressInfo = this.data.addressInfo
    var productsArr = this.data.productsArr
    var account = this.data.account
    var orderInfo = []
    this.getOrder()



  },

  getOrder: function() {
    var addressInfo = this.data.addressInfo
    var productsArr = this.data.productsArr
    var account = this.data.account
    order.doOrder(productsArr, addressInfo, account, (data) => {
      for (let i = 0; i < data.length; i++) {
        var orderInfo = data[i]
      }
      pay.pay(0.01, orderInfo, addressInfo)

    })

  },



  /*
   * 提示窗口
   * params:
   * title - {string}标题
   * content - {string}内容
   * flag - {bool}是否跳转到 "我的页面"
   */
  showTips: function(title, content, flag) {
    wx.showModal({
      title: title,
      content: content,
      showCancel: false,
      success: function(res) {
        if (flag) {
          wx.switchTab({
            url: '/pages/my/my'
          });
        }
      }
    });
  },

  /*
   *下单失败
   * params:
   * data - {obj} 订单结果信息
   * */
  _orderFail: function(data) {

    var nameArr = [],
      name = '',
      str = '',
      pArr = data.pStatusArray;
    for (let i = 0; i < pArr.length; i++) {
      if (!pArr[i].haveStock) {
        name = pArr[i].name;
        if (name.length > 15) {
          name = name.substr(0, 12) + '...';
        }
        nameArr.push(name);
        if (nameArr.length >= 2) {
          break;
        }
      }
    }
    str += nameArr.join('、');
    if (nameArr.length > 2) {
      str += ' 等';
    }
    str += ' 缺货';
    wx.showModal({
      title: '下单失败',
      content: str,
      showCancel: false,
      success: function(res) {

      }
    });
  },

  /* 再次次支付*/
  _oneMoresTimePay: function() {
    this._execPay(this.data.id);
  },

  /*
   *开始支付
   * params:
   * id - {int}订单id
   */
  _execPay: function(id) {

    if (!order.onPay) {
      this.showTips('支付提示', '本产品仅用于演示，支付系统已屏蔽', true); //屏蔽支付，提示
      this.deleteProducts(); //将已经下单的商品从购物车删除
      return;
    }
    var that = this;
    order.execPay(id, (statusCode) => {
      if (statusCode != 0) {
        that.deleteProducts(); //将已经下单的商品从购物车删除   当状态为0时，表示

        var flag = statusCode == 2;
        wx.navigateTo({
          url: '../pay-result/pay-result?id=' + id + '&flag=' + flag + '&from=order'
        });
      }
    });
  },

  //将已经下单的商品从购物车删除
  deleteProducts: function() {
    var ids = [],
      arr = this.data.productsArr;
    for (let i = 0; i < arr.length; i++) {
      ids.push(arr[i].id);
    }
    cart.delete(ids);
  },


})