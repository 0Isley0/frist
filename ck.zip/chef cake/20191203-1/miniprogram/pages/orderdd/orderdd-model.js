/**
 * Created by jimmy on 17/03/09.
 */

import {
  Base
} from '../../utils/base.js'
import {
  Sign
} from '../../utils/sign.js';
var timestamp = Date.parse(new Date())
var hsha256 = require('../../utils/sign.js');
var data3 = []
class Orderdd extends Base {

  constructor() {
    super();
    this._storageKeyName = 'newOrder';
  }


  /*下订单*/
  getOrderdd(dd1,callback) {
    var that = this;
    var param = {
      data: {
        orderId: dd1
      },
      url: 'takeout/order/status/get?',
      data: {orderId:dd1},
      sCallback: function(data1) {
        data1 = data1;
        
        callback && callback(data1);
      }
    };
    this.request(param);
  }

getOrderIdd(callback) {
  var that = this;
  const db = wx.cloud.database()
  db.collection('otder').field({
    orderId1: true,
    deliveryStatus: true
  })

    .get({
      success: function (res) {
        var dd = res.data

        for (var i = 0; i < res.data.length; i++) {

          var dd1 = res.data[i].orderId1
          orderdd.getOrderdd(dd1, (data1) => {

            wx.cloud.callFunction({
              name: 'add_deliveryStatus1',
              data: {
                orderId1: data1.result.orderId,
                deliveryStatus: data1.result.deliveryStatus,
              },
              success: function (res) {

              },

            })

          })
        }

      }
    })
  db.collection('order').where({}).get({
    success(res) {      
      var data = res.data
     
        callback && callback(data);
    }


  })



}
}

export {
  Orderdd
};