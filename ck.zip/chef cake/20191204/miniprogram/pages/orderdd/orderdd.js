// pages/coupon/index.js
import {
  Orderdd
} from '../orderdd/orderdd-model.js';
import {
  Cart
} from '../cart/cart-model.js';
import {
  Address
} from '../../utils/address.js';
import {
  Sign
} from '../../utils/sign.js';


var orderdd = new Orderdd();
var cart = new Cart();
var address = new Address();

var pay = require('../../utils/pay.js')
var addclose = require('../../utils/addclose.js')

var hsha256 = require('../../utils/sign.js');
var timestamp = Date.parse(new Date());
var list1 = []




var appkey = '6933f4b502b8c48e4499785d27e47320'
var shopIdenty = '810453311'
var token = '093302d5130749756f7c8615cd9c15c6'
var key = '&appKey=' + appkey + '&shopIdenty=' + shopIdenty + '&version=1.0&timestamp=' + timestamp + '&sign=';
var key1 = 'appKey' + appkey + 'shopIdenty' + shopIdenty + 'timestamp' + timestamp + 'version1.0' + token;
var sign = hsha256.sha256(key1);
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    tabIndex: 0,
    list: [],
    ddxq: [],
    tabIndex1: 0,
    transClassArr: ['tanslate0', 'tanslate1', 'tanslate2', 'tanslate3'],
    tabInfo: ['待付款', '待发货', '已发货', '已完成'],
    currentMenuIndex: 0,
    loadingHidden: false,
    scrollLeft: 0,
    hasUserInfo: false,
    prevIndex: -1,
    classfiySelect: "",
    currentTab: 0,
    navScrollLeft: 0,
    swiper_height: 0,
    currentTab1: 0,
    isIndex: 0,
    tabIndexTab: 0,
    tabIndexTab1: 0

  },





  // },
  changetabInfo: function(event, index) {
    var cur = event.currentTarget.dataset.current;
    console.log(cur, 'bb')

    if (this.data.tabIndexTab == cur) {
      return false;
      tabIndex1: tabIndexTab;
    } else {
      this.setData({
        tabIndexTab: cur,
      });
    }



  },
  switchTab(event) {
    var cur = event.detail.current;
    var singleNavWidth = this.data.canUseWidth / 4;
    this.setData({
      tabIndexTab1: cur,
      tabIndexTab: cur,
      navScrollLeft: (cur) * singleNavWidth
    });


  },

  getList1() {
    orderdd.getOrderIdd((data) => {
      this.setData({
        ddxq: data
      })
      var pending = []
      var paid = []
      var shipper = []
      var tobeshipper = []

      var ddxq = this.data.ddxq
      for (let i = 0; i < ddxq.length; i++) {

        if (ddxq[i].deliveryStatus == "0") {
          pending.push(ddxq[i])


        }
        if (ddxq[i].deliveryStatus == "2") {
          tobeshipper.push(ddxq[i])

        }
        if (ddxq[i].deliveryStatus == "3") {
          shipper.push(ddxq[i])

        }
        if (ddxq[i].deliveryStatus == "4") {
          paid.push(ddxq[i])

        }
      }




      this.setData({
        ddxqq0:pending
      })

      this.setData({
        ddxqq1: tobeshipper
      })

      this.setData({
        ddxqq2: shipper
      })

      this.setData({
        ddxqq3: paid
      })
    })

  },
  

  updateGoods: function(goodList) {
    console.log(goodList)
    for (var i = 0; i < goodList.length; i++) {
      console.log(goodList[i].products.length)
      console.log(goodList[i])
      for(let j in goodList){
           goodList[i] = goodList[i].products[j].name
        // goodList[i] = goodList[i].products[j].totalFee/100
        // goodList[i] = goodList[i].products[j].price/100
      }
      // for (var j = 0; j < goodList[i].products.length; j++) {
      //   goodList[i] = goodList[i].products[j].name
      //   // goodList[i] = goodList[i].products[j].totalFee/100
      //   // goodList[i] = goodList[i].products[j].price/100
      // }
    }
    return goodList;
  },




  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {


    this.getList1()

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

    this.getList1()
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var that = this

    that.getList1()

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})