import {
  Base
} from '../../utils/base.js';
import {
  Token
} from '../../utils/token.js';



class Login extends Base {
  constructor() {
    super();
  }
  getUserInfo(callback) {
    var that = this;
    var param = {
      data:{customerId: wx.getStorageSync('lobot')},
      url: 'crm/getCustomerDetailById?',
      sCallback: function (data) {
        data = data;
        callback && callback(data);
      }
    };
    this.request(param);
  }
  getUser(callback) {
    var that = this;
    var param = {
      data: { customerId: wx.getStorageSync('lobot') },
      url: 'crm/login',
      sCallback: function (data) {
        data = data;
        callback && callback(data);
      }
    };
    this.request(param);
  }


  getUsertoken(callback) {
  var that = this;
  var param = {
    data: { customerId: wx.getStorageSync('lobot') },
    url: 'crm/autoLogin',
    sCallback: function (data) {
      data = data;
      callback && callback(data);
    }
  };
  this.request(param);
}
};
  
  export {
    Login
  };