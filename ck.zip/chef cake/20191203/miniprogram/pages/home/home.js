import {
  Home
} from 'home-model.js';
var home = new Home(); //实例化 首页 对象
import {
  Sign
} from '../../utils/sign.js';

var hsha256 = require('../../utils/sign.js');
var timestamp = Date.parse(new Date());
var appkey = '6933f4b502b8c48e4499785d27e47320'
var shopIdenty = 810453311
var token = '093302d5130749756f7c8615cd9c15c6'
var key = '&appKey=' + appkey + '&shopIdenty=' + shopIdenty + '&version=1.0&timestamp=' + timestamp + '&sign=';
var key1 = 'appKey' + appkey + 'shopIdenty' + shopIdenty + 'timestamp' + timestamp + 'version1.0' + token;
var sign = hsha256.sha256(key1);
Page({
  data: {
    loadingHidden: false

  },
  onLoad: function () {
    this._loadData();
    text: '';
  }, 
  onShow: function () {
    const db = wx.cloud.database()
    db.collection('openId').where({
    })
      .get({
        success: function (res1) {
          
          wx.request({
            url: 'https://openapi.keruyun.com/open/v1/crm/login?' + key + sign, // 仅为示例，并非真实的接口地址
            method: 'POST',
            data: {
              loginId: res1.data[0].mobile,
              loginType: 0
            },
            header: {
              'content-type': 'application/json' // 默认值
            },
            dataType: 'text',
            success(res) {
              var data = JSON.parse(res.data.replace(/:(\d{10,})(,?)/g, ':"$1"$2'))
            
            }
             
          })
         

        }
      })
  },




  /*加载所有数据*/
  _loadData: function(callback) {
    var that = this;
    var a = this.data;

    // var b = '286448732798937100';

    // function myFilter(arr1, arr2) {
    //   return arr1.filter((ele) =>
    //     arr2.filter(
    //       ele((x) => x.id === ele.id).length > 0
    //     );


    //   }
    //   var c = myFilter(a,b);
    //   console.log(c)








    // 获得bannar信息
    home.getBannerData((data) => {
      that.setData({
        bannerArr: data,
        loadingHidden: true
      });
    });

    /*获取主题信息*/
    home.getThemeData((data) => {
      that.setData({
        themeArr: data,
        loadingHidden: true
      });
    });

    home.getUserInfo((data) => {
      that.setData({
        use: data,
        loadingHidden: true
      });

    });


    /*获取单品信息*/

    home.getProductorData((data) => {
      that.setData({
        productsArr: this.updateGoods(filterByName1(data)),
      });
      callback && callback();
      loadingHidden: true
    });





    var productsArr = this.data

    function filterByName1(productsArr, attrsArr) {
      let result = []
      for (let i = 0; i < productsArr.length; i++) {
        for (let j = 0; j < productsArr[i].attrs.length; j++) {
          if (productsArr[i].attrs[j].name == "新品") {
            result.push(productsArr[i])
          }
        }

      }
      return result
    }


  },
  
  updateGoods: function(goodList) {
    for (var i = 0; i < goodList.length; i++) {
      goodList[i].imgUrl = goodList[i].imgUrl.split('x-oss-process=image/resize,w_640,h_480,');
      goodList[i].price = goodList[i].price / 100;
      goodList[i].categoryId = goodList[i].categorys[0].categoryId;
      goodList[i].categoryName = goodList[i].categorys[0].categoryName
    }
    return goodList;
  },




  /*跳转到商品详情*/
  onProductsItemTap: function(event) {
    var id = home.getDataSet(event, 'id');
    wx.navigateTo({
      url: '../product/product?id=' + id
    })
  },

  /*跳转到主题列表*/
  onThemesItemTap: function(event) {
    var id = home.getDataSet(event, 'id');
    var name = home.getDataSet(event, 'name');
    wx.navigateTo({
      url: '../theme/theme?id=' + id + '&name=' + name
    })
  },
  

  /*下拉刷新页面*/
  onPullDownRefresh: function() {
    this._loadData(() => {
      wx.stopPullDownRefresh()
    });
  },

  //分享效果
  onShareAppMessage: function() {
    return {
      title: '零食商贩 Pretty Vendor',
      path: 'pages/home/home'
    }
  }

})