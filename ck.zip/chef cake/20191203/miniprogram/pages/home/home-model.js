/**
 * Created by jimmy on 17/2/26.
 */

// var Base = require('../../utils/base.js').base;
import {
  Base
} from '../../utils/base.js';
import {
  Token
} from '../../utils/token.js';



class Home extends Base {
  constructor() {
    super();
  }
  getUserInfo(callback) {
    var that = this;
    var param = {
      data: {
        shopIdenty: '810453311'
      },
      url: 'crm/getCustomerDetailById?',
      sCallback: function(data) {
        data = data;
        callback && callback(data);
      }
    };
    this.request(param);
  }

  /*banner图片信息*/
  getBannerData(callback) {
    var that = this;
    var param = {
      data: {
        shopIdenty: '810453311'
      },
      url: 'crm/login?',
      sCallback: function(data) {
        data = data;
        callback && callback(data);
      }

    };
    this.request(param);
  }
  /*首页主题*/
  getThemeData(callback) {
    var param = {
      data: {
        shopIdenty: '810453311'
      },
      url: 'cater/dish/dishMenuByIds?',
      sCallback: function(data) {
        data = data
        callback && callback(data);
      }
    };
    this.request(param);
  }

  /*首页部分商品*/
  getProductorData(callback) {
    var param = {
      data: {
        shopIdenty: '810453311'
      },
      url: 'cater/dish/dishMenu?',
      sCallback: function(data) {
        data = data.result.dishTOList


        callback && callback(data);
      }
    };
    this.request(param);
  }

};

export {
  Home
};