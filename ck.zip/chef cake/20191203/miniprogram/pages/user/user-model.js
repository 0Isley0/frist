/**
 * Created by jimmy on 17/3/24.
 */
import {
  Base
} from '../../utils/base.js'

class User extends Base {
  constructor() {
    super();
  }

  //得到用户信息
  getUserInfo(callback) {
    var param = {
      data: { customerId: wx.getStorageSync('lobot') },
      url: 'crm/getCustomerDetailById?',
      sCallback: function (data) {
        callback && callback(data);
      }
    };
    this.request(param);
  }


}
export {
  User
}