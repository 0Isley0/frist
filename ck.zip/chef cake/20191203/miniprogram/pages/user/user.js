// pages/user/index.js
import {
  User
} from 'user-model.js';
import {
  Address
} from '../../utils/address.js';

import {
  Sign
} from '../../utils/sign.js';
var address = new Address();
const app = getApp()
var user = new User();
var hsha256 = require('../../utils/sign.js');
var timestamp = Date.parse(new Date());
var appkey = '6933f4b502b8c48e4499785d27e47320'
var shopIdenty = 810453311
var token = '093302d5130749756f7c8615cd9c15c6'
var key = '&appKey=' + appkey + '&shopIdenty=' + shopIdenty + '&version=1.0&timestamp=' + timestamp + '&sign=';
var key1 = 'appKey' + appkey + 'shopIdenty' + shopIdenty + 'timestamp' + timestamp + 'version1.0' + token;
var sign = hsha256.sha256(key1);

Page({

  /**
   * 页面的初始数据
   */
  data: {
    isEdit: false,
    userInfo: '',

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this._loadData();


  },
  bot: function() {
    const db = wx.cloud.database()
    wx.chooseAddress({
      success: function(res) {
        console.log(res)
        var data = res
        db.collection('user').add({
          data: {
            name: res.userName,
            mobile: res.telNumber,
            totalDetail: address.setAddressInfo(res),
            province: res.provinceName,
            city: res.cityName,
            country: res.countyName,            
            detail: res.detailInfo,

          },
          success: function(res) {}
        })

      }
    })
  },

  _loadData: function(callback) {
    var that = this;
    user.getUserInfo((data) => {
      that.setData({
        userInfo: data.result
      });
      if (this.data.userInfo != null) {

        if (this.data.userInfo.level == 1) {

          this.setData({
            isEdit: true

          });
        }
      } else {
        this.setData({
          isEdit: false

        });
      }

      callback && callback(data);
      loadingHidden: true

    });





  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {


  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    console.log('开')
    const db = wx.cloud.database()
    db.collection('openId').where({})
      .get({
        success: function(res1) {
          if (res1.data[0] == null) {
            console.log(res1.data)
            wx.navigateTo({
              url: '/pages/login/login',
            })
          } else {
            wx.request({
              url: 'https://openapi.keruyun.com/open/v1/crm/login?' + key + sign, // 仅为示例，并非真实的接口地址
              method: 'POST',
              data: {
                loginId: res1.data[0].mobile,
                loginType: 0
              },
              header: {
                'content-type': 'application/json' // 默认值
              },
              dataType: 'text',
              success(res) {
                var data = JSON.parse(res.data.replace(/:(\d{10,})(,?)/g, ':"$1"$2'))
                console.log(res)




              }

            })


          }
        }
      })


  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {


  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {


  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})