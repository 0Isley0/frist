// pages/addressAdd/index.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    region: ['广东省', '广州市', '海珠区'],
    customItem: '全部',
    name: '',
    mobile: '',
    detailed: '',
    addressIs: true,
    _id: '',
    id: ''
  },

  bindRegionChange: function(e) {
    this.setData({
      region: e.detail.value
    })
  },
  bindKeyName: function(e) {
    this.setData({
      name: e.detail.value
    })
  },
  bindKeyMobile: function(e) {
    this.setData({
      mobile: e.detail.value
    })
  },
  bindKeyDetailed: function(e) {
    this.setData({
      detailed: e.detail.value
    })
  },
  submitFun: function() {
    const db = wx.cloud.database()
    if (this.data.isFly) {
      return;
    }

    if (this.fun() == false) {
      return
    }
    if (this.data.addressIs) { //添加
      db.collection('user').add({
        data: {
          name: this.data.name,
          mobile: this.data.mobile,
          detailed: this.data.detailed,
          city: this.data.region,
        },
        success: function(res) {
          wx.navigateBack({
            delta: 1
          })
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '新增记录失败'
          })
          console.error('[数据库] [新增记录] 失败：', err)
        }
      })
    } else {
      wx.cloud.callFunction({
        name: 'setressAdd',
        data: {
          name: this.data.name,
          mobile: this.data.mobile,
          detailed: this.data.detailed,
          city: this.data.region,
          dataId: this.data._id
        },
        success: function(res) {
          wx.navigateTo({
            url: '/pages/addressList/addressList'
          });
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '新增记录失败'
          })
          console.error('[数据库] [新增记录] 失败：', err)
        }
      })

    }
  },

  fun: function() {
    if (this.data.name == '') {
      wx.showToast({
        title: '请输入联系人'
      })
      return false
    }
    var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
    if (this.data.mobile == '') {
      wx.showToast({
        title: '请输入手机号'
      })
      return false
    }
    if (myreg.test(this.data.mobile)) {} else {
      wx.showToast({
        title: '请输入正确手机号'
      })
      return false
    }
    if (this.data.detailed == '') {
      wx.showToast({
        title: '详细地址'
      })
      return false
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    if (options.id) {
      this.setData({
        region: options.city.split(','),
        name: options.name,
        mobile: options.mobile,
        detailed: options.detailed,
        _id: options.id,
        addressIs: false
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})