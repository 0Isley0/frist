// var productObj = require('product-model.js');

import {
  Product
} from 'product-model.js';
import {
  Cart
} from '../cart/cart-model.js';

var product = new Product(); //实例化 商品详情 对象
var cart = new Cart();


Page({
  data: {
    loadingHidden: false,
    hiddenSmallImg: true,
    countsArray: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    productCounts: 1,
    currentTabsIndex: 0,
    cartTotalCounts: 0,
    showModalStatus: false,
    animationData: {},
    choose: 0,
    selectedPrice: 0,
   


  },






  onLoad: function(option) {
    var id = option.id;
    this.data.id = id;
    this._loadData();





  },
  /* 获取数据 */





  /*加载所有数据*/
  _loadData: function(callback) {
    var that = this;
    var productsArr = this.data
    var id = this.data.id
    var gglist = this.data
    var namen = ''


    function filterByName1(productsArr, categoryIdArr) {
      let result = []

      for (let i = 0; i < productsArr.length; i++) {

        if (productsArr[i].id == id) {
          result.push(productsArr[i])
        }
      }
      console.log(productsArr)
      return result
    }

    
 


    function filterByName3(ggList) {
   
   

      let gg1 = []

      for (let i = 0; i < ggList.length; i++) {
        if (ggList[i].id == id) {
          namen = ggList[i].name
        }
        for (let j = 0; j < ggList[i].attrs.length; j++) {
          if (ggList[i].name == namen && ggList[i].attrs[j].name != '小程序' ) {
            gg1.push(ggList[i])

          }
        }
      }
      console.log(namen)
      return gg1;
    }



    product.getDetailInfo(this.data.id, (data) => {
      that.setData({
        cartTotalCounts: cart.getCartTotalCounts().counts1,
        product: filterByName1(this.updateGoods(data)),
        gg: data,
        gg1: this.compare(filterByName3(data)),
        // gg2: this.compare(data),

        loadingHidden: true
      });

      callback && callback();
    });






  },


  updateGoods: function(goodList) {
    for (var i = 0; i < goodList.length; i++) {

      goodList[i].imgUrl = goodList[i].imgUrl.split('x-oss-process=image/resize,w_640,h_480,');
      goodList[i].price = goodList[i].price / 100;
      goodList[i].categoryId = goodList[i].categorys[0].categoryId;
      goodList[i].categoryName = goodList[i].categorys[0].categoryName;
      goodList[i].imgUrlT = goodList[i].imgUrl[0];
      
    }
    return goodList;
  },
  compare: function(gg2List) {
    var list = []
    var gg1=[]
    var arrs = [];
    //遍历当前数组 
    for (var i = 0; i < gg2List.length; i++) {
      //如果临时数组里没有当前数组的当前值，则把当前值push到新数组里面 
      if (arrs.indexOf(gg2List[i]) == -1) {
        arrs.push(gg2List[i])
      };
    }
    for (let j = 0; j < arrs[0].attrs.length; j++) {
      if (arrs[0].attrs[j].name != '小程序' && arrs[0].attrs[j].name != '推荐' && arrs[0].attrs[j].name != '新品' && arrs[0].attrs[j].name != '热门'
        && arrs[0].attrs[j].name != '特价' && arrs[0].attrs[j].name != '赠品') {
        list.push(arrs[0].attrs[j])
        
      }
    }
    console.log(list)
    arrs[0].attrs=list
    
    return arrs;
  },

 









  /*选取规格信息*/
  choosesize1: function(event) {
    var index = product.getDataSet(event, 'index');
    this.setData({
      currentTabsIndex: index
    });
    
    wx.setStorageSync('n1', this.data.gg1[index])
  

  },





  /*添加到购物车*/

  onAddingToCartTap: function(events) {
    //防止快速点击
    if (this.data.isFly) {
      return;
    }
    this._flyToCartEffect(events);
    this.addToCart();
  },
  
  _getProductIndexById: function(id) {

  },

  /*储存规格缓存给其他缓存使用*/

  /*将商品数据添加到内存中*/
  addToCart: function(event) {
    var n = wx.getStorageSync('n1')
    if (!n) {
      n = this.data.product[0]
    }

    var tempObj = {},
    
      keys = ['id', 'name', 'price', 'size', 'tool', 'imgUrlT','attrs'];
    for (var key in n) {
      if (keys.indexOf(key) >= 0) {
        tempObj[key] = n[key];
      }

    }

    cart.add(tempObj, this.data.productCounts);

  },





  /*加入购物车动效*/
  _flyToCartEffect: function(events) {
    //获得当前点击的位置，距离可视区域左上角
    var touches = events.touches[0];
    var diff = {
        x: '25px',
        y: 25 - touches.clientY + 'px'
      },
      style = 'display: block;-webkit-transform:translate(' + diff.x + ',' + diff.y + ') rotate(350deg) scale(0)'; //移动距离
    this.setData({
      isFly: true,
      translateStyle: style
    });
    var that = this;
    setTimeout(() => {
      that.setData({
        isFly: false,
        translateStyle: '-webkit-transform: none;', //恢复到最初状态
        isShake: true,
      });
      setTimeout(() => {
        var counts = that.data.cartTotalCounts + that.data.productCounts;
        that.setData({
          isShake: false,
          cartTotalCounts: counts
        });
      }, 200);
    }, 1000);
    
  },



  /*跳转到购物车*/
  onCartTap: function() {
    wx.switchTab({
      url: '/pages/cart/cart'
    });

  },
  /*添加到购物车+1*/

  onAddingToCartTap1: function(events) {

    //防止快速点击
    if (this.data.isFly) {
      return;
    }
    this._flyToCartEffect(events);
    this.addToCart();
    wx.switchTab({
      url: '/pages/cart/cart'
    });
  },



  /*跳转购物详情*/
  clickme: function () {
    this.showModal();
  },
  showModal: function(event) {
    // 用that取代this，防止不必要的情况发生
    var that = this;
    // 创建一个动画实例
    var animation = wx.createAnimation({
      // 动画持续时间
      duration: 200,
      // 定义动画效果，当前是匀速
      timingFunction: 'linear',
      delay: 0
    })
    // 将该变量赋值给当前动画
    that.animation = animation
    // 先在y轴偏移，然后用step()完成一个动画
    animation.translateY(200).step()
    // 用setData改变当前动画
    that.setData({
      // 通过export()方法导出数据
      animationData: animation.export(),
      // 改变view里面的Wx：if
      showModalStatus: true
    })
    // 设置setTimeout来改变y轴偏移量，实现有感觉的滑动
    setTimeout(function() {
      animation.translateY(0).step()
      that.setData({
        animationData: animation.export(),
      })
    }.bind(this), 200)
    console.log(event.currentTarget.dataset.id)
    var index = product.getDataSet(event, 'index');
   

    wx.setStorageSync('n1', this.data.gg1[index])


  

  },
  hideModal: function() {
    var that = this;
    var animation = wx.createAnimation({
      duration: 500,
      timingFunction: 'linear',
      delay: 0,
    })
    that.animation = animation
    animation.translateY(200).step()
    that.setData({
      animationData: animation.export(),
    })
    setTimeout(function() {
      animation.translateY(0).step()
      that.setData({
        animationData: animation.export(),
        showModalStatus: false
      })
    }.bind(this), 200)
  },


  /*下拉刷新页面*/
  onPullDownRefresh: function() {
    this._loadData(() => {
      wx.stopPullDownRefresh()
    });
  },
  //分享效果
  onShareAppMessage: function() {
    return {
      title: '零食商贩 Pretty Vendor',
      path: 'pages/product/product?id=' + this.data.id
    }
  }
})

// function newArr(array) {
//   //一个新的数组 
//   var arrs = [];
//   //遍历当前数组 
//   for (var i = 0; i < array.length; i++) {
//     //如果临时数组里没有当前数组的当前值，则把当前值push到新数组里面 
//     if (arrs.indexOf(array[i]) == -1) {
//       arrs.push(array[i])
//     };
//   }
//   return arrs;
// }

// var arr = [1, 1, 2, 5, 5, 6, 8, 9, 8];
