/**
 * Created by jimmy on 17/2/26.
 */

import {
  Base
} from '../../utils/base.js';


class Product extends Base {
  constructor() {
    super();
  }
  getDetailInfo(id, callback) {
    var param = {
      data: {
        shopIdenty: '810453311'
      },
      url: 'cater/dish/dishMenu?',
        sCallback: function(data) {
          data = data.result.dishTOList
        callback && callback(data);
      }
    };
    this.request(param);
  }
  getDetailPropertiesInfo(id, callback) {    
    var param = {
      data: {
        shopIdenty: '810453311'
      },
      url: 'cater/dish/dishMenus?',
        sCallback: function(data) {
          data = data.result.dishTOList
        callback && callback(data);
      }
    };
    this.request(param);
  }

};

export {
  Product
}