// pages/coupon/index.js
import {
  Orderdd
} from '../orderdd/orderdd-model.js';
import {
  Cart
} from '../cart/cart-model.js';
import {
  Address
} from '../../utils/address.js';
import {
  Sign
} from '../../utils/sign.js';


var orderdd = new Orderdd();
var cart = new Cart();
var address = new Address();

var pay = require('../../utils/pay.js')
var addclose = require('../../utils/addclose.js')

var hsha256 = require('../../utils/sign.js');
var timestamp = Date.parse(new Date());
var list1 = []




var appkey = '6933f4b502b8c48e4499785d27e47320'
var shopIdenty = '810453311'
var token = '093302d5130749756f7c8615cd9c15c6'
var key = '&appKey=' + appkey + '&shopIdenty=' + shopIdenty + '&version=1.0&timestamp=' + timestamp + '&sign=';
var key1 = 'appKey' + appkey + 'shopIdenty' + shopIdenty + 'timestamp' + timestamp + 'version1.0' + token;
var sign = hsha256.sha256(key1);
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    tabIndex: 1,
    list: [],
    ddxq : []
  },
  tabFun(e) {
    this.setData({
      tabIndex: e.currentTarget.dataset.index
    })
    this.getList()
    this.getList1()

  },
  
   getList1() {
  const db = wx.cloud.database()
    db.collection('takeout').field({
    orderId1: true,
    deliveryStatus: true
  })

    .get({
      success: function (res) {
        var dd = res.data

        for (var i = 0; i < res.data.length; i++) {

          var dd1 = res.data[i].orderId1
          orderdd.getOrderdd(dd1, (data1) => {

            wx.cloud.callFunction({
              name: 'add_deliveryStatus1',
              data: {
                orderId1: data1.result.orderId,
                deliveryStatus: data1.result.deliveryStatus,
              },
              success: function (res) {

              },

            })

          })
        }

      }
    })
    db.collection('takeout').where({}).get({
      success(res) {
        var pending=[]
        var paid=[]
        var shipper=[]
        var tobeshipper=[]
        var ddxq=res.data
        for (let i = 0; i < ddxq[i].length; i++) {        

            if (ddxq[i].deliveryStatus == "0" ) {
              pending.push(ddxq[i])
              if (ddxq[i].deliveryStatus == "2") {
                tobeshipper.push(ddxq[i])
              }
              if (ddxq[i].deliveryStatus == "3") {
                shipper.push(ddxq[i])
              }
              if (ddxq[i].deliveryStatus == "4") {
                paid.push(ddxq[i])
              }
          }
          return result
        }
       
        wx.setStorageSync('res', res.data)
      }
       
    })
     this.setData({
       ddxq: wx.getStorageSync('res')
     })
     
  },


  getList() {
    // app.http('/v1/order/list', { state: this.data.tabIndex }).then(res => {
    //   this.setData({ list: res.data })
    // })
    const db = wx.cloud.database()
    wx.cloud.callFunction({
      name: 'login',
      complete: res => {
        db.collection('cart').where({}).get({
          success: res => {
            let list = []
            res.data.map((v, k) => {

            })

            this.setData({
              list: list,
              total: false,
              totalPrice: 0,
            })
          },
          fail: err => {
            wx.showToast({
              icon: 'none',
              title: '查询记录失败'
            })
            console.error('[数据库] [查询记录] 失败：', err)
          }
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.setData({
      tabIndex: options.type || 1
    })
    this.getList()
    this.getList1()
    
    // const db = wx.cloud.database()

    // db.collection('takeout').field({
    //   orderId1: true,
    //   deliveryStatus: true
    // })

    //   .get({
    //     success: function (res) {
    //       var dd = res.data
        
    //       for (var i = 0; i < res.data.length; i++) {
            
    //         var dd1 = res.data[i].orderId1
    //         orderdd.getOrderdd(dd1, (data1) => {
             
    //           wx.cloud.callFunction({
    //             name: 'add_deliveryStatus1',
    //             data: {
    //               orderId1: data1.result.orderId,
    //               deliveryStatus: data1.result.deliveryStatus,
    //             },
    //             success: function (res) {
                  
    //             },

    //           })

    //         })
    //       }

    //     }
    //   })

    // db.collection('takeout').where({}).get({
    //   success(res) {
    //     console.log('最终数组', res.data)
    //     this.setData({
    //       ddxq: res
    //     })
    //   }
    // })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var that = this
    this.getList1()
    // orderdd.getOrderdd((data1) => {
    //   that.setData({
    //     deliveryStatus: data1
    //   })

    //   wx.cloud.callFunction({
    //     name: 'add_deliveryStatus',
    //     data: {
    //       tpOrderId: addclose.closid(),
    //       deliveryStatus: data1,
    //     },
    //     success: function(res) {

    //     },
    //     fail: console.error
    //   })
    // })
    // const db = wx.cloud.database()

    // db.collection('takeout').field({
    //   orderId1: true,
    //   deliveryStatus: true
    // })

    //   .get({
    //     success: function (res) {
    //       var dd = res.data
         
    //       for (var i = 0; i < res.data.length; i++) {
            
    //         var dd1 = res.data[i].orderId1
    //         orderdd.getOrderdd(dd1, (data1) => {
              
    //           wx.cloud.callFunction({
    //             name: 'add_deliveryStatus1',
    //             data: {
    //               orderId1: data1.result.orderId,
    //               deliveryStatus: data1.result.deliveryStatus,
    //             },
    //             success: function (res) {
                 
                 
    //             },

    //           })

    //         })
    //       }

    //     }
    //   })

    // db.collection('takeout').where({}).get({
    //   success(res) {
    //     console.log('最终数组', res.data)
    //     this.setData({          
    //       ddxq:res
    //     })
    //   }
    // })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})