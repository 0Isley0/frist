/**
 * Created by jimmy on 17/03/09.
 */

import {
  Base
} from '../../utils/base.js'
import {
  Sign
} from '../../utils/sign.js';
var timestamp = Date.parse(new Date())
var hsha256 = require('../../utils/sign.js');
var data3 = []
class Orderdd extends Base {

  constructor() {
    super();
    this._storageKeyName = 'newOrder';
  }


  /*下订单*/
  getOrderdd(dd1,callback) {
    var that = this;
    var param = {
      data: {
        orderId: dd1
      },
      url: 'takeout/order/status/get?',
      data: {orderId:dd1},
      sCallback: function(data1) {
        data1 = data1;
        
        callback && callback(data1);
      }
    };
    this.request(param);
  }
}




export {
  Orderdd
};