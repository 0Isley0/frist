import {
  Category
} from 'category-model.js';

var category = new Category(); //实例化 home 的推荐页面



Page({
  data: {
    transClassArr: ['tanslate0', 'tanslate1', 'tanslate2', 'tanslate3', 'tanslate4', 'tanslate5'],
    currentMenuIndex: 0,
    loadingHidden: false,
    scrollLeft: 0,
    hasUserInfo: false,
    prevIndex: -1,
    classfiySelect: "",
    currentTab: 0,
    navScrollLeft: 0,
    swiper_height: 0,
    currentTab1: 0,
    isIndex: 0
  },



  onLoad: function(options) {
    this._loadData();


    let qSearch = wx.createSelectorQuery();
    var that = this


    // var productsArr1= this.data
    // function filterByNamea(productsArr1, ggIdArr) {
    //   let result = []
    //   console.log(productsArr1.length);
    //   for (let i = 0; i < productsArr.length; i++) {
    //     for (let j = 0; j < productsArr[i].attrs.length; j++) {
    //       if (productsArr[i].attrs[j].name == "推荐") {
    //         result.push(productsArr1[i])
    //       }
    //     }
    //   }
    //   return result
    // }

    qSearch.select('.header').boundingClientRect()

    // qSearch.exec(function (res) {
    //   that.setData({
    //     useHeith: res[0].height
    //   })

    wx.getSystemInfo({
      success: function(res) {
        that.setData({
          canUseWidth: res.windowWidth,
          canUseHeith: res.windowHeight,
          scrollViewHeith: res.windowHeight
        })

      }
    })
    // })



  },








  /*加载所有数据*/
  _loadData: function(callback) {
    var that = this;


    category.getCategoryType((categoryData) => {

      that.setData({
        categoryTypeArr: categoryData.result,
        loadingHidden: true,
      });
    });

    that.getProductsByCategory((data) => {

      var dataObj = {
        procucts: this.updateGoods(filterByName1(data)),
        // procucts:data
      };

      that.setData({
        loadingHidden: true,
        categoryInfo0: dataObj
      });

      callback && callback();

    });


    var productsArr = this.data


    function filterByName1(productsArr, categoryIdArr) {
      let result = []

      for (let i = 0; i < productsArr.length; i++) {
        for (let j = 0; j < productsArr[i].categorys.length; j++) {
          for (let k = 0; k < productsArr[i].attrs.length; k++) {

            if (productsArr[i].categorys[j].categoryId == "286448732798937088" && productsArr[i].attrs[k].name == "小程序") {

              result.push(productsArr[i])
            }
          }
        }
      }
      return result
    }
  

    that.getProductsByCategory((data) => {

      var dataObj = {
        procucts: this.updateGoods(filterByName2(data)),
      };

      that.setData({
        loadingHidden: true,
        categoryInfo1: dataObj
      });

      callback && callback();

    });

    var productsArr = this.data


    function filterByName2(productsArr, categoryIdArr) {
      let result = []


      for (let i = 0; i < productsArr.length; i++) {
        for (let j = 0; j < productsArr[i].categorys.length; j++) {
          for (let k = 0; k < productsArr[i].attrs.length; k++) {

            if (productsArr[i].categorys[j].categoryId == "286448935333488640" && productsArr[i].attrs[k].name == "小程序") {

              result.push(productsArr[i])
            }
          }
        }
      }
      return result
    }
  
    that.getProductsByCategory((data) => {

      var dataObj = {
        procucts: this.updateGoods(filterByName3(data)),
      };

      that.setData({
        loadingHidden: true,
        categoryInfo2: dataObj
      });

      callback && callback();

    });

    var productsArr = this.data


    function filterByName3(productsArr, categoryIdArr) {
      let result = []
      // let sat = []

      for (let i = 0; i < productsArr.length; i++) {
        for (let j = 0; j < productsArr[i].categorys.length; j++) {
          for (let k = 0; k < productsArr[i].attrs.length; k++) {

            if (productsArr[i].categorys[j].categoryId == "286449293299376128" && productsArr[i].attrs[k].name == "小程序") {

              result.push(productsArr[i])
            }
          }
        }
      }
      return result
    }
  
  


     


     


    that.getProductsByCategory((data) => {

      var dataObj = {
        procucts: this.updateGoods(filterByName4(data)),
      };

      that.setData({
        loadingHidden: true,
        categoryInfo3: dataObj
      });

      callback && callback();

    });

    var productsArr = this.data


    function filterByName4(productsArr, categoryIdArr) {
      let result = []


      for (let i = 0; i < productsArr.length; i++) {
        for (let j = 0; j < productsArr[i].categorys.length; j++) {
          for (let k = 0; k < productsArr[i].attrs.length; k++) {

            if (productsArr[i].categorys[j].categoryId == "286449338523543552" && productsArr[i].attrs[k].name == "小程序") {

              result.push(productsArr[i])
            }
          }
        }
      }
      return result
    }
  
    that.getProductsByCategory((data) => {

      var dataObj = {
        procucts: this.updateGoods(filterByName5(data)),
      };

      that.setData({
        loadingHidden: true,
        categoryInfo4: dataObj
      });

      callback && callback();


    });

    var productsArr = this.data


    function filterByName5(productsArr, categoryIdArr) {
      let result = []

      for (let i = 0; i < productsArr.length; i++) {
        for (let j = 0; j < productsArr[i].categorys.length; j++) {
          for (let k = 0; k < productsArr[i].attrs.length; k++) {
            
              if (productsArr[i].categorys[j].categoryId == "286449358826987520" && productsArr[i].attrs[k].name == "小程序" ) {
          
              result.push(productsArr[i])
            }
          }
        }
      }
      return result
    }
  },


  updateGoods: function(goodList) {
    for (var i = 0; i < goodList.length; i++) {

    
      goodList[i].imgUrl = goodList[i].imgUrl.split('x-oss-process=image/resize,w_640,h_480,')
      
      goodList[i].price = goodList[i].price / 100;
      goodList[i].categoryId = goodList[i].categorys[0].categoryId;
      goodList[i].categoryName = goodList[i].categorys[0].categoryName
    }
    return goodList;
  },





  /*切换分类*/
  changeCategory: function(event) {
    var index = category.getDataSet(event, 'index'),
      id = category.getDataSet(event, 'id'); //获取data-set
    var cur = event.currentTarget.dataset.current;
    var singleNavWidth = this.data.canUseWidth / 6;
    //tab选项居中                            
    this.setData({
      navScrollLeft: (cur - 1) * singleNavWidth,

    })
    if (this.data.currentTab == cur) {
      return false;
      currentMenuIndex: currentTab;
    } else {
      this.setData({
        currentTab: cur,


      });
    }


    //如果数据是第一次请求
    if (!this.isLoadedData(index)) {
      var that = this;
      this.getProductsByCategory(id, (data) => {
        that.setData(that.getDataObjForBind(index, data));
      });
    }
  },

  isLoadedData: function(index) {
    if (this.data['categoryInfo' + index]) {
      return true;
    }
    return false;
  },

  getDataObjForBind: function(index, data) {
    var obj = {},
      arr = [0, 1, 2, 3, 4, 5],
      baseData = this.data.categoryTypeArr[index];
    for (var item in arr) {
      if (item == arr[index]) {
        obj['categoryInfo' + item] = {
          procucts: data,

        };

        return obj;
      }
    }
  },

  getProductsByCategory: function(id, callback) {
    category.getProductsByCategory(id, (data) => {
      callback && callback(data);
    });
  },



  switchTab(event) {
    var cur = event.detail.current;
    var singleNavWidth = this.data.canUseWidth / 6;
    this.setData({
      currentTab1: cur,
      currentTab: cur,
      navScrollLeft: (cur - 1) * singleNavWidth
    });


  },



  /*跳转到商品详情*/
  onProductsItemTap: function(event) {
    var id = category.getDataSet(event, 'id');
    wx.navigateTo({
      url: '../product/product?id=' + id
    })
  },

  /*下拉刷新页面*/
  onPullDownRefresh: function() {
    this._loadData(() => {
      wx.stopPullDownRefresh()
    });
  },

  //分享效果
  onShareAppMessage: function() {
    return {
      title: '零食商贩 Pretty Vendor',
      path: 'pages/category/category'
    }
  }


})



      // var count = -1
      // productsArr.map((v, k) => {
      //   count++
      //   for (let i = count; i < productsArr.length - 1; i++) {
      //     if (v.name == productsArr[i].name) {
      //       console.log(productsArr[i].name)
      //     }
      //   }
      // })

      // var list = [1, 2, 3, 1, 1, 2, 3, ]
      // var count = -1
      // var lists=[]
      // var li=[]
      // list.map((v, k) => {
      //   count++
      //   for (let i = count; i <= list.length ; i++) {
      //     if (list[count] == list[i+1 ]) {
      //       lists.push(list[i + 1])
      //     }
      //   }

      // })
      // for (let i = 0; i < list.length; i++) {
      //   console.log(lists[i])
      // }



      // for (let i = 0; i < list.length; i++) {
      //   for (let j = 0; j < list.length; j++) {
      //   console.log(list[j])
      //   console.log(list[i])
      //   }
      // }
