/**
 * Created by jimmy on 17/2/26.
 */
import {Base} from '../../utils/base.js';


class Category extends Base {
    constructor() {
        super();
    } 

     

    /*获得所有分类*/
    getCategoryType(callback) {
        var param = {
          data: {
            shopIdenty: '810453311'
          },
          url: 'cater/dish/category/?' ,
          
            sCallback: function (data) {
                callback && callback(data);
            }
        };
        this.request(param);
    }
    /*获得某种分类的商品*/
    getProductsByCategory(callback) {
        var param = {
          data: {
            shopIdenty: '810453311'
          },
          url: 'cater/dish/dishMenu?',
                sCallback: function (data) {
                  data = data.result.dishTOList
                
                callback && callback(data);
            }
            
        };
        this.request(param);
  } 
  getProductorData(callback) {
    var param = {
      data: {
        shopIdenty: '810453311'
      },
      url: 'cater/dish/dishMenu?',
      sCallback: function (data) {
        data = data.result.dishTOList


        callback && callback(data);
      }
    };
    this.request(param1);
  }
 
  

}

export{Category};