
Page({
        data: {
          text: ''

        },
        onLoad: function (options){
            this.setData({
                payResult:options.flag,
                id:options.id,
                from:options.from
            });
        },
  getpassword: function (e) {
    this.setData({
      password:'appKey7857ca1808d370e2501290bc853eecdcshopIdenty810094162timestamp1528683797798version1.066e53b22f1496d183e71b4ab90f4acf7'
    })
  },
  changeHash: function (e) {
    var hsha256 = require('../../utils/sha256.js');
    var pass = hsha256.sha256(password)
    this.setData({
      text: pass
    })
  },
        viewOrder:function(){
            if(this.data.from=='my'){
                wx.redirectTo({
                    url: '../order/order?from=order&id=' + this.data.id
                });
            }else{
                //返回上一级
                wx.navigateBack({
                    delta: 1
                })
            }
        }
    }
)