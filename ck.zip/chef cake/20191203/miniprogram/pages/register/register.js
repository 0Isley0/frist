import {
  Register
} from 'register-model.js';
import {
  Sign
} from '../../utils/sign.js';
var register = new Register();
var hsha256 = require('../../utils/sign.js');
var timestamp = Date.parse(new Date());
var appkey = '6933f4b502b8c48e4499785d27e47320'
var shopIdenty = 810453311
var token = '093302d5130749756f7c8615cd9c15c6'
var key = '&appKey=' + appkey + '&shopIdenty=' + shopIdenty + '&version=1.0&timestamp=' + timestamp + '&sign=';
var key1 = 'appKey' + appkey + 'shopIdenty' + shopIdenty + 'timestamp' + timestamp + 'version1.0' + token;
var sign = hsha256.sha256(key1);
var interval = null //倒计时函数
Math.random().toString(12).substring(2); //6位
var i = Math.random() * (999999 - 100000) + 100000;
var st = parseInt(i)
Page({
  data: {
    'loginId': '',
    'loginType': '',
    'lobot': '',
    fun_id: 2,
    time: '获取验证码', //倒计时 
    currentTime: 61,
    st: st,
    

    inputstate: {
      'pasInput': true,
      'pasIcon': '../../imgs/icon/eyeclos.png'
    }

  },
  
  // 获取输入账号 
  phoneInput: function(e) {
    var that = this
    this.setData({
      loginId: e.detail.value
    })
    wx.setStorageSync('loginId1', e.detail.value)
    console.log(e.detail.value)
  },


  // 获取输入密码 
  passwordInput: function(e) {
    this.setData({
      loginType: e.detail.value
    })
    console.log(e.detail.value)
  },
  // 获取地址 
  addressInput: function(e) {
    this.setData({
      loginType: e.detail.value
    })
    console.log(e.detail.value)
  },
  // 获取邮箱 
  emailInput: function(e) {
    this.setData({
      loginType: e.detail.value
    })
    console.log(e.detail.value)
  },
  // 获取爱好 
  loveInput: function(e) {
    this.setData({
      loginType: e.detail.value
    })
    console.log(e.detail.value)
  },
  // 获取输入密码 
  passwordInput: function(e) {
    this.setData({
      loginType: e.detail.value
    })
    console.log(e.detail.value)
  },

  // 清理用户名
  userNameClick: function() {
    this.setData({
      'userInfo.loginId': ''
    })
  },

  login: function(e) {
    var that = this
    var st1 = this.data.st
    
    var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
    if (this.data.loginId == '') {
      wx.showToast({
        title: '请输入手机号'
      })
      return false
    }
    if (myreg.test(this.data.loginId)) {} else {
      wx.showToast({
        title: '请输入正确手机号'
      })
      return false
    }
    if (this.data.loginType.length == 0) {
      wx.showToast({
        title: '账号或密码不能为空',
      })
      return false
    }
    if (this.data.loginType != this.data.st) {
         wx.showToast({
          title: '验证码错误',
        })
        return false
    } else {
      var lid = this.data.loginId
      var lidd = '0'
      wx.request({
        url: 'https://openapi.keruyun.com/open/v1/crm/login?' + key + sign, // 仅为示例，并非真实的接口地址
        method: 'POST',
        data: {
          loginId: lid,
          loginType: lidd
        },
        header: {
          'content-type': 'application/json' // 默认值
        },
        dataType: 'text',
        success(res) {
          var data = JSON.parse(res.data.replace(/:(\d{10,})(,?)/g, ':"$1"$2'))
          console.log('去', data)
          if (data.result == null) {

            wx.showToast({
              title: data.message,
              icon: 'loading',
              duration: 2000
            })
            return
          }
          wx.setStorageSync('lobot', data.result.customerId)

          wx.switchTab({
            url: '/pages/user/user'
          })

        }
      })
    }

  },


  submitInfo(event) {
    console.log('GG 敌方军团已同意投降 4票赞成 0票反对')
    console.log(event.detail.formId);

    this.setData({

      formid: event.detail.formId
      
    })
    
  },

  // 是否是密码框ven
  submitInfo(event) {  
    // let fromid = this.data.formid
    console.log(st);
        wx.cloud.callFunction({
          name: "openapi",
          data: {
            formId: event.detail.formId,
            st1:st,
          },
          success(res) {

            console.log('成功', res)
          },

          fail(res) {
            console.log('失败', res)

          }
        })
      },





      getCode: function (options) {
    var that = this;
    var currentTime = that.data.currentTime

    interval = setInterval(function () {
      currentTime--;
      that.setData({
        time: currentTime + '秒'
      })
      if (currentTime <= 0) {
        clearInterval(interval)
        that.setData({
          time: '重新发送',
          currentTime: 61,
          disabled: false
        })
      }
    }, 100)
  },
  getVerificationCode() {
    this.getCode();
    var that = this
    that.setData({
      disabled: true
    })
  },

})

    
    












