import {
  Base
} from '../../utils/base.js';
import {
  Token
} from '../../utils/token.js';



class Register extends Base {
  constructor() {
    super();
  }
  getUserInfo(callback) {
    var that = this;
    var param = {
      url: 'crm/getCustomerDetailById?',
      sCallback: function (data) {
        data = data;
        callback && callback(data);
      }
    };
    this.request(param);
  }
  getUser(callback) {
    var that = this;
    var param = {
      url: 'crm/login',
      sCallback: function (data) {
        data = data;
        callback && callback(data);
      }
    };
    this.request(param);
  }


  getUsertoken(callback) {
  var that = this;
  var param = {
    url: 'crm/autoLogin',
    sCallback: function (data) {
      data = data;
      callback && callback(data);
    }
  };
  this.request(param);
}
};
  
  export {
  Register
  };