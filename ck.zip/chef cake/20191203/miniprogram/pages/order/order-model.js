/**
 * Created by jimmy on 17/03/09.
 */

import {
  Base
} from '../../utils/base.js'
import {
  Sign
} from '../../utils/sign.js';
import {
  Config
} from '../../utils/config.js';
var timestamp = Date.parse(new Date())
var appkey = '6933f4b502b8c48e4499785d27e47320'
var shopIdenty = '810453311'
var token = '093302d5130749756f7c8615cd9c15c6'
var hsha256 = require('../../utils/sign.js');
var key = '&appKey=' + appkey + '&shopIdenty=' + shopIdenty + '&version=1.0&timestamp=' + timestamp + '&sign=';
var key1 = 'appKey' + appkey + 'shopIdenty' + shopIdenty + 'timestamp' + timestamp + 'version1.0' + token;
var sign = hsha256.sha256(key1);
var pay = require('../../utils/pay.js')

class Order extends Base {

  constructor() {
    super();
    this._storageKeyName = 'newOrder';
    "use strict";
    this.baseRestUrl = Config.restUrl;
  }

  /*下订单*/
  doOrder(productsArr, addressInfo, account, callback) {
    const db = wx.cloud.database()
    var that = this;
    var products = [];
    for (var i = 0; i < productsArr.length; i++) {
      var productsArr = productsArr
      productsArr[i].type = 0;
      productsArr[i].tpId = 0
      productsArr[i].price = productsArr[i].price * 100
      productsArr[i].quantity = productsArr[i].counts;
      productsArr[i].totalFee = productsArr[i].counts * (productsArr[i].price )
      productsArr[i].packagePrice=0
      productsArr[i]. packageQuantity=0
      products.push(productsArr[i])
    }
    db.collection('order').add({
      data: {
        tpOrderId: pay.getNowTime(),
        createTime: timestamp,
        peopleCount: 1,
        remark: "",
        shop: {
          shopIdenty: 810453311,
          tpShopId: "88888888",
          shopName: "微信小程序-chefcake"
        },
        products: products,
        delivery: {
          expectTime: 0,
          deliveryParty: 1,
          receiverName: addressInfo.name,
          receiverPhone: addressInfo.mobile,
          receiverGender: 1,
          delivererPhone: "13921061258",
          delivererAddress: addressInfo.totalDetail,
          coordinateType: 1,
          longitude: 119.500747,
          latitude: 31.447402
        },
        payment: {
          deliveryFee: 0,
          packageFee: 0,
          discountFee: 0,
          platformDiscountFee: 0,
          shopFee: account * 100,
          userFee: account * 100,
          serviceFee: 0,
          subsidies: 0,
          totalFee: account * 100,
          payType: 2,
          shopDiscountFee: 0
        },
        isPrint: 0,
        printTemplateTypes: [9],
        deliveryStatus: 0,
        orderId2:0,
        deliveryStatus:0
      },
      success: function(res) {
        db.collection('order').where({}).get({
          success: function(res) {
            var data = res.data
           
            console.log(data)
            callback && callback(data);
          }
          
        })
        
      },

    })

  }

  /*
   * 拉起微信支付
   * params:
   * norderNumber - {int} 订单id
   * return：
   * callback - {obj} 回调方法 ，返回参数 可能值 0:商品缺货等原因导致订单不能支付;  1: 支付失败或者支付取消； 2:支付成功；
   * */
  execPay(orderNumber, callback) {
    var allParams = {
      url: 'pay/pre_order',
      type: 'POST',
      data: {
        id: orderNumber
      },
      sCallback: function(data) {
        var timeStamp = data.timeStamp;
        if (timeStamp) { //可以支付
          wx.requestPayment({
            'timeStamp': timeStamp.toString(),
            'nonceStr': data.nonceStr,
            'package': data.package,
            'signType': data.signType,
            'paySign': data.paySign,
            success: function() {
              callback && callback(2);
            },
            fail: function() {
              callback && callback(1);
            }
          });
        } else {
          callback && callback(0);
        }
      }
    };
    this.request(allParams);
  }

  /*获得所有订单,pageIndex 从1开始*/
  getOrders(pageIndex, callback) {
    var allParams = {
      url: 'crm/login?',
      data: {
        page: pageIndex
      },
      type: 'POST',
      sCallback: function(data) {
        callback && callback(data); //1 未支付  2，已支付  3，已发货，4已支付，但库存不足
      }
    };
    this.request(allParams);
  }

  /*获得订单的具体内容*/
  getOrderInfoById(id, callback) {
    var that = this;
    var allParams = {
      url: 'order/' + id,
      sCallback: function(data) {
        callback && callback(data);
      },
      eCallback: function() {}
    };
    this.request(allParams);
  }
  getOrderd(dd, callback) {
    var that = this;
    var param = {
      data: {
        tpOrderId: dd.tpOrderId,
        createTime: dd.createTime,
        peopleCount: dd.peopleCount,
        remark: "",
        shop: {
          shopIdenty: 810453311,
          tpShopId: "88888888",
          shopName: "微信小程序-chefcake"
        },
        products: dd.products,
        delivery: {
          expectTime: 0,
          deliveryParty: 1,
          receiverName: dd.delivery.receiverName,
          receiverPhone: dd.delivery.receiverPhone,
          receiverGender: 1,
          delivererPhone: "13921061258",
          delivererAddress: dd.delivery.delivererAddress,
          coordinateType: 1,
          longitude: 119.500747,
          latitude: 31.447402
        },
        payment: {
          deliveryFee: 0,
          packageFee: 0,
          discountFee: 0,
          platformDiscountFee: 0,
          shopFee: dd.payment.shopFee,
          userFee: dd.payment.userFee,
          serviceFee: 0,
          subsidies: 0,
          totalFee: dd.payment.totalFee,
          payType: 2,
          shopDiscountFee: 0
        },
        isPrint: 0,
        printTemplateTypes: [9],
        deliveryStatus: 0
      },
      url: 'takeout/order/create?',
      sCallback: function(data) {
        data = data;      
        callback && callback(data);
      }
    };
  
    this.request(param);
  }
  getOrderdd(dd1, callback) {
    var that = this;
    var param = {
      data: {
        orderId: dd1.orderId2
      },
      url: 'takeout/order/status/get?',
      sCallback: function(data1) {
        data1 = data1.result;
        callback && callback(data1);
      }
    };
    this.request(param);
  }



  /*本地缓存 保存／更新*/
  execSetStorageSync(data) {
    wx.setStorageSync(this._storageKeyName, data);
  };

  /*是否有新的订单*/
  hasNewOrder() {
    var flag = wx.getStorageSync(this._storageKeyName);
    return flag == true;
  }

}


export {
  Order
};