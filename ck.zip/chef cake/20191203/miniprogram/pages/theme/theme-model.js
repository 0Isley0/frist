/**
 * Created by jimmy on 17/2/26.
 */
import {Base} from '../../utils/base.js';
var hsha256 = require('../../utils/sign.js');
var timestamp = Date.parse(new Date());

timestamp = timestamp;

var key = 'appKey=7e8b1934870d961c72a7dad5ac0a7740&shopIdenty=810094162&version=1.0&timestamp=' + timestamp + '&sign=';
var key1 = 'appKey7e8b1934870d961c72a7dad5ac0a7740shopIdenty810094162timestamp' + timestamp + 'version1.0' + '6798d20a614512a3b166db45da7c6262';
var sign = hsha256.sha256(key1) 

class Theme extends Base{
    constructor(){
        super();
    }

    /*商品*/
    getProductorData(id,callback){
        var param={
            url: 'theme/'+id,
            sCallback:function(data){
                callback && callback(data);
            }
        };
        this.request(param);
    }
};

export {Theme};