import {
  Base
} from '../../utils/base.js'
import {
  Sign
} from '../../utils/sign.js';

var hsha256 = require('../../utils/sign.js');
var timestamp = Date.parse(new Date());
var appkey = '6933f4b502b8c48e4499785d27e47320'
var shopIdenty = 810453311
var token = '093302d5130749756f7c8615cd9c15c6'
var key = '&appKey=' + appkey + '&shopIdenty=' + shopIdenty + '&version=1.0&timestamp=' + timestamp + '&sign=';
var key1 = 'appKey' + appkey + 'shopIdenty' + shopIdenty + 'timestamp' + timestamp + 'version1.0' + token;
var sign = hsha256.sha256(key1);

class Printer extends Base {
  constructor() {
    super();
  }

  getTakeout(callback) {
    var param = {
      url: 'takeout/order/create?',
      sCallback: function (data) {
        callback && callback(data);
      }
    };
    this.request(param);
  }
}
export {
  Printer
}