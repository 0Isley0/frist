import {
  Address
} from '../../utils/address.js';
import {
  Order
} from '../order/order-model.js';
import {
  Printer
} from 'printer-moled.js';
var printer = new Printer();

Page({

  /**
   * 页面的初始数据
   */
  

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
   
      this._loadData();
    
  
  },

  _loadData: function (callback) {
    var that = this;
    printer.getTakeout((data) => {
      that.setData({
        takeout: data
      });
      callback && callback(data);
      loadingHidden: true
    });
  }
  })