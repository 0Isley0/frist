/**
 * Created by jimmy on 17/3/24.
 */
import {
  Base
} from '../../utils/base.js'
import {
  Sign
} from '../../utils/sign.js';

var hsha256 = require('../../utils/sign.js');
var timestamp = Date.parse(new Date());
var appkey = '6933f4b502b8c48e4499785d27e47320'
var shopIdenty = 810453311
var token = '093302d5130749756f7c8615cd9c15c6'
var key = '&appKey=' + appkey + '&shopIdenty=' + shopIdenty + '&version=1.0&timestamp=' + timestamp + '&sign=';
var key1 = 'appKey' + appkey + 'shopIdenty' + shopIdenty + 'timestamp' + timestamp + 'version1.0' + token;
var sign = hsha256.sha256(key1);

class My extends Base {
  constructor() {
    super();
  }

  //得到用户信息
  getUserInfo(callback) {
    var param = {
      data: { customerId: wx.getStorageSync('lobot') },
      url: 'crm/getCustomerDetailById?',
      sCallback: function(data) {
        callback && callback(data);
      }
    };
    this.request(param);
  }

  // wx.login({
  // success: function () {
  // wx.getUserInfo({
  //   success: function (res) {
  //     typeof cb == "function" && cb(res.userInfo);

  //将用户昵称 提交到服务器
  // if (!that.onPay) {
  //   that._updateUserInfo(res.userInfo);
  // }



  // fail: function(res) {
  //   typeof cb == "function" && cb({
  //     avatarUrl: '../../imgs/icon/user@default.png',
  //     nickName: '顾客'
  //   });
  // }


  //   });
  // },

  // })


  /*更新用户信息到服务器*/
  // _updateUserInfo(res) {
  //   var nickName = res.nickName;
  //   delete res.avatarUrl; //将昵称去除
  //   delete res.nickName; //将昵称去除
  //   var allParams = {
  //     url: 'crm/login?',
  //     // data: { nickname: nickName, extend: JSON.stringify(res) },
  //     type: 'POST',
  //     sCallback: function(data) {}
  //   };
  //   this.request(allParams);

  // }
}
export {
  My
}