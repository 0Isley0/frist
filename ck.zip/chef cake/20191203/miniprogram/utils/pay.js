import {
  Sign
} from 'sign.js';

class Pay {}
var body = 'chef cake'
var attach = '烘焙产品'
var type = ''
var fee = 0
var trade_no = ''
var addclose = require('/addclose.js')



var hsha256 = require('/sign.js');
var timestamp = Date.parse(new Date());
var list1 = []



var appkey = '6933f4b502b8c48e4499785d27e47320'
var shopIdenty = '810453311'
var token = '093302d5130749756f7c8615cd9c15c6'
var key = '&appKey=' + appkey + '&shopIdenty=' + shopIdenty + '&version=1.0&timestamp=' + timestamp + '&sign=';
var key1 = 'appKey' + appkey + 'shopIdenty' + shopIdenty + 'timestamp' + timestamp + 'version1.0' + token;
var sign = hsha256.sha256(key1);


function getNowTime() {
  var now = new Date();
  var id = 'No';
  var year = now.getFullYear();
  var month = now.getMonth() + 1;
  var day = now.getDate();
  if (month < 10) {
    month = '0' + month;
  };
  if (day < 10) {
    day = '0' + day;
  };
  var i = Math.random() * (9999 - 1000) + 1000;
  var st = parseInt(i)
  var formatDate = id + year.toString() + month.toString() + day.toString() +
    st.toString();
  return formatDate;


}

//清空购物车已下单的产品
function removebot() {
  for (let i in list1) {
    wx.getStorageSync('cart')(list1[i].id).remove({
      success: function (res) { }
    })
  }
}


// 支付订单
function pay(account,orderInfo, addressInfo) {
  type = 'unify'
  trade_no = orderInfo.tpOrderId
  fee = account
  wxPayment(fee,orderInfo, addressInfo)
}
// 支付订单查询
function payCheck() {
  type = 'payCheck'
  wxPayment()
}
// 订单退款
function refund() {
  type = 'refund'
  wxPayment()
}
// 订单退款查询
function refundCheck() {
  type = 'refundCheck'
  wxPayment()
}
// 取消支付，刚生产的支付订单，5分钟后才能取消支付
function cancelPay() {
  type = 'cancelPay'
  wxPayment()
}



function wxPayment(fee,orderInfo, addressInfo) {
  var refund_no = 'refund' + trade_no
  wx.cloud.callFunction({
    name: 'wxPayment',
    data: {
      type: type,
      trade_no: trade_no,
      refund_no: refund_no,
      body: body,
      attach: attach,
      total_fee: fee,
      refund_fee: fee,
      ip: '171.107.61.167' // 用户的客户端IP
    },
    success(res) {
      if (type == 'unify') {
        res = res.result
        if (res.return_code && res.return_code == "SUCCESS") {
          if (res.result_code && res.result_code == "SUCCESS") {
            wx.requestPayment({
              timeStamp: res.timeStamp,
              nonceStr: res.nonceStr,
              package: res.package,
              signType: res.signType,
              paySign: res.paySign,
              success(res1) {
                console.log('成功')
               
              },
              fail(res1) {
                console.log('失败')
                wx.showToast({
                  title: '支付失败',
                  icon: 'none'
                })
                wx.redirectTo({
                  url: '/pages/orderdd/orderdd?type=1',
                })
              }
            })
          } else {
            wx.showToast({
              title: '该订单已经支付成功，无法重新支付',
              icon: 'none'
            })
            console.log('出错啦(' + res.err_code_des + ')')
          }
        } else {
          wx.showToast({
            title: '请求失败，请重试',
            icon: 'none'
          })
          console.log('请求失败，请重试', res)
        }

      } else if (type == 'payCheck') {
        res = res.result
        if (res.return_code && res.return_code == "SUCCESS") {
          if (res.result_code && res.result_code == "SUCCESS") {
            
       
            if (res.trade_state_desc =="订单未支付"){
              addclose.close(res)              
            }else{              
              addclose.close(res)
            }
            // wx.showToast({
            //   title: res.trade_state == 'SUCCESS' ? '订单已成功支付了' : res.trade_state_desc,
            //   icon: 'none'
            // })
          } else {
            wx.showToast({
              title: res.err_code_des,
              icon: 'none'
            })
            console.log('出错啦(' + res.err_code_des + ')')
          }
        } else {
          wx.showToast({
            title: '请求失败，请重试',
            icon: 'none'
          })
          console.log('请求失败，请重试', res)
        }
      } else if (type == 'refund') {
        console.log(res)
        res = res.result
        if (res.return_code && res.return_code == "SUCCESS") {
          if (res.result_code && res.result_code == "SUCCESS") {
            wx.showToast({
              title: '订单退款成功',
              icon: 'none'
            })
          } else {
            var msg = res.err_code == 'ORDERNOTEXIST' ? '退款订单不存在' : res.err_code_des
            wx.showToast({
              title: msg,
              icon: 'none'
            })
            console.log('出错啦(' + msg + ')')
          }
        } else {
          wx.showToast({
            title: '请求失败，请重试',
            icon: 'none'
          })
          console.log('请求失败，请重试', res)
        }
      } else if (type == 'refundCheck') {
        console.log(res)
        res = res.result
        if (res.return_code && res.return_code == "SUCCESS") {
          if (res.result_code && res.result_code == "SUCCESS") {
            wx.showToast({
              title: '订单已成功退款了',
              icon: 'none'
            })
          } else {
            var msg = res.err_code == 'REFUNDNOTEXIST' ? '退款信息不存在' : res.err_code_des
            wx.showToast({
              title: msg,
              icon: 'none'
            })
            console.log('出错啦(' + msg + ')')
          }
        } else {
          wx.showToast({
            title: '请求失败，请重试',
            icon: 'none'
          })
          console.log('请求失败，请重试', res)
        }
      } else if (type == 'cancelPay') {
        console.log(res)
        res = res.result
        if (res.return_code && res.return_code == "SUCCESS") {
          if (res.result_code && res.result_code == "SUCCESS") {
            wx.showToast({
              title: '成功取消支付',
              icon: 'none'
            })
          } else {
            var msg = res.err_code == 'ORDERPAID' ? '订单已支付无法取消' : res.err_code_des
            wx.showToast({
              title: msg,
              icon: 'none'
            })
            console.log('出错啦(' + msg + ')')
          }
        } else {
          wx.showToast({
            title: '请求失败，请重试',
            icon: 'none'
          })
          console.log('请求失败，请重试', res)
        }
      }
    },
    fail(res) {
      console.log(res)
    }
  })
}

function random() {
  var i = Math.random() * (9999 - 1000) + 1000;
  var st = parseInt(i)
  return st.toString()
}
//单号
// function getNowTime1() {
//   var now = new Date();
//   var id = '1901';
//   var year = now.getFullYear();
//   var month = now.getMonth() + 1;
//   var day = now.getDate();
//   if (month < 10) {
//     month = '0' + month;
//   };
//   if (day < 10) {
//     day = '0' + day;
//   };
//   var h = now.getHours();
//   var m = now.getMinutes();
//   var s = now.getSeconds();
//   var st = year.toString().substring(2, 4)
//   var formatDate = id + st.toString() + month.toString() + day.toString() + h.toString() + m.toString() + s.toString() +
//     random1();
//   return formatDate;
// }

module.exports = {
  getNowTime: getNowTime, //订单的id
  pay: pay, // 支付订单
  payCheck: payCheck, //查询支付订单
  refund: refund,
  refundCheck: refundCheck,
  cancelPay: cancelPay,
}