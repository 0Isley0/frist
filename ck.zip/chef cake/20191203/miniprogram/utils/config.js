
class Config{
    constructor(){
      

    }
}

Config.restUrl = 'https://openapi.keruyun.com/open/v1/';
// Config.onPay=true;  //是否启用支付

export {Config};

// http://z.cn/api/v1/