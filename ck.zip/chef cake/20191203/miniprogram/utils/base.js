/**
 * Created by jimmy-jiang on 2016/11/21.
 */
import {
  Token
} from 'token.js';
import {
  Config
} from 'config.js';
import {
  Sign
} from 'sign.js';



var hsha256 = require('/sign.js');
var timestamp = Date.parse(new Date());
// timestamp = timestamp;



var appkey = '6933f4b502b8c48e4499785d27e47320'
var shopIdenty = '810453311'
var token = '093302d5130749756f7c8615cd9c15c6'
// var appkey = '7e8b1934870d961c72a7dad5ac0a7740'
// var shopIdenty = 810094162
// var token = '6798d20a614512a3b166db45da7c6262'


//  wx.getStorageSync('ids')

var key = '&appKey=' + appkey + '&shopIdenty=' + shopIdenty + '&version=1.0&timestamp=' + timestamp + '&sign=';
var key1 = 'appKey' + appkey + 'shopIdenty' + shopIdenty + 'timestamp' + timestamp + 'version1.0' + token;
var sign = hsha256.sha256(key1);



// var datas = {
//   shopIdenty: shopIdenty,
//   startId: 1,
//   pageNum: 1000,  
//   dishTypeId: '286448732798937100',
//   customerId: wx.getStorageSync('lobot'),
//   isNeedCredit: '0',
//   loginType:'0',
//   loginId: loginId1
// };



class Base {
  constructor() {
    "use strict";
    this.baseRestUrl = Config.restUrl;
    this.onPay = Config.onPay;

  }


  //http 请求类, 当noRefech为true时，不做未授权重试机制
  request(params, noRefetch) {
    var that = this,
      url = this.baseRestUrl + params.url + key + sign;
    if (!params.type) {
      params.type = 'POST';
    }
    /*不需要再次组装地址*/
    if (params.setUpUrl == false) {
      url = params.url;
    }
    
    wx.request({
      url: url,
      data: params.data,

      method: params.type,
      header: {
        'content-type': 'application/json',
        // 'token': wx.getStorageSync('token')
      },
      dataType: 'text',
      success: function(res) {
        var data = JSON.parse(res.data.replace(/:(\d{10,})(,?)/g, ':"$1"$2'))

        // 判断以2（2xx)开头的状态码为正确
        // 异常不要返回到回调中，就在request中处理，记录日志并showToast一个统一的错误即可
        // var code = res.statusCode.toString();
        // var startChar = code.charAt(0);
        // if (startChar == '2') {
        
        params.sCallback && params.sCallback(data);

        //   } else {
        //     if (code == '401') {
        //       if (!noRefetch) {
        //         that._refetch(params);
        //       }
        //     }
        //     that._processError(res);
        //     params.eCallback && params.eCallback(res.data);
        //   }
        // },
        // fail: function(err) {
        //   //wx.hideNavigationBarLoading();
        //   that._processError(err);
        //   // params.eCallback && params.eCallback(err);

      }
    });
  }


  // _processError(err) {
  //   console.log(err);
  // }

  // _refetch(param) {
  //   var token = new Token();
  //   token.getTokenFromServer((token) => {
  //     this.request(param, true);
  //   });
  // }



  /*获得元素上的绑定的值*/
  getDataSet(event, key) {
    return event.currentTarget.dataset[key];
  };

};



export {
  Base
};


//