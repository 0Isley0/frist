// 引用使用es6的module引入和定义
// 全局变量以g_开头
// 私有函数以_开头

import { Config } from 'config.js';
 
var hsha256 = require('/sign.js');
var timestamp = Date.parse(new Date());

timestamp = timestamp;

var key = 'appKey=7e8b1934870d961c72a7dad5ac0a7740&shopIdenty=810094162&version=1.0&timestamp=' + timestamp + '&sign=';
var key1 = 'appKey7e8b1934870d961c72a7dad5ac0a7740shopIdenty810094162timestamp' + timestamp + 'version1.0' + '6798d20a614512a3b166db45da7c6262';
var sign = hsha256.sha256(key1) 



class Token {
    constructor() {
      this.verifyUrl = Config.restUrl ;
      this.tokenUrl = Config.restUrl  ;
    }

    verify() {
        var token = wx.getStorageSync('token');
        if (!token) {
            this.getTokenFromServer();
        }
        else {
            this._veirfyFromServer(token);
        } 
    }

    _veirfyFromServer(token) {
        var that = this;
        wx.request({
            url: that.verifyUrl,
            method: 'POST',
            data: {
                token: token
            },
            success: function (res) {
                var valid = res.data.isValid;
                if(!valid){
                    that.getTokenFromServer();
                }
            }
        })
    }

    getTokenFromServer(callBack) {
        var that  = this;
        wx.login({
            success: function (res) {
                wx.request({
                    url: that.tokenUrl,
                    method:'POST',
                    data:{
                        code:res.code
                    },
                    success:function(res){
                        wx.setStorageSync('token', res.data.token);
                        callBack&&callBack(res.data.token);
                    }
                })
            }
        })
    }
}

export {Token};