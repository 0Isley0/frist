// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
  // API 调用都保持和云函数当前所在环境一致
  env: cloud.DYNAMIC_CURRENT_ENV
})

// 云函数入口函数
exports.main = async(event, context) => {
  try {
    // 调用 update 方法
    // users 是我要修改的集合的名字
    // event.dataId 和 event.lover 是我调用此云函数带的参数

    return await db.collection('takeout').doc(event.dataId).update({
      // data 为 users 集合内我要修改的内容 lover 为字段名 event.lover 为要修改成的内容
      data: {
        tpOrderId: enent.tpOrderId,
        // needInvoice: 0,
        // invoiceTitle: "我要发票，这是抬头",
        createTime: 1491906548372,
        peopleCount: 1,
        remark: "",
        shop: {
          shopIdenty: 810453311,
          tpShopId: "88888888",
          shopName: "微信小程序-chefcake"
        },
        products: event.products,
        delivery: {
          expectTime: 0,
          deliveryParty: 1,
          receiverName:event.dname,
          receiverPhone: event.dmobile,
          receiverGender: 1,
          delivererPhone: "13921061258",
          delivererAddress: event.delivererAddress,
          coordinateType: 1,
          longitude: 119.500747,
          latitude: 31.447402
        },
        payment: {
          // memberId: customerId??
          // memberPassword:123456,
          deliveryFee: 0,
          packageFee: 0,
          discountFee: 0,
          platformDiscountFee:0,
          shopFee: event.account,
          userFee: event.account,
          serviceFee: 0,
          subsidies: 0,
          totalFee: pprice * pconts,
          payType: 2,
          shopDiscountFee:0
        },
        isPrint: 1,
        printTemplateTypes: [9]
      }
    })
  } catch (e) {
    console.error(e)
  }



}