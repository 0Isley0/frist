let config = {
  appid: 'wx07edd508e2984e38',
  mch_id: '1561893081',
  mch_key: 'shenwuqiaffshenwuqiahh5683446431',
  cert_file: __dirname + '/ssl/cert.pem', // 微信支付秘钥cert文件,退款接口会用到
  key_file: __dirname + '/ssl/key.pem', // 微信支付秘钥key文件,退款接口会用到
  notify_url: 'https://mp.weixin.qq.com',
  trade_type: 'JSAPI'
}, httpsOpts = {
  hostname: 'api.mch.weixin.qq.com',
  port: 443,
  method: 'POST',
  path: ''
}

module.exports = {
  config,
  httpsOpts
}